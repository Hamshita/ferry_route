from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description="its a wheat seeds package", 
    author="Hamshita", 
    packages=find_packages(),
    license="MIT"
)
